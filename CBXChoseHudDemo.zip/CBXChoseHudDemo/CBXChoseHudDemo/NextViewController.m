//
//  NextViewController.m
//  CBXChoseHudDemo
//
//  Created by 陆正现 on 2018/3/1.
//  Copyright © 2018年 陆正现. All rights reserved.
//

#import "NextViewController.h"

#import "CBXChoseHud.h"

@interface NextViewController ()

@property(nonatomic,assign)int index;

@end

@implementation NextViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor greenColor];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    
    [[CBXChoseHud shareHud] showHudWithContentTitle:@[@"标题1",@"标题2标题2标题2",@"标题3标题3标题3标题3标题3标题3标题3标题3标题3标题3标题3标题3标题3标题3标题3"] andFontArr:@[@(17),@(14),@(10)] andLeftChose:@"左按钮" andLeftColor:[UIColor redColor] andRightChose:@"右按钮" andRightColor:[UIColor blueColor] inViewController:self clickBlock:^(ClickType type) {
        
        if (type == clickLeft) {
            NSLog(@"点击左按钮");
        }else {
            NSLog(@"点击右按钮");
        }
    }];
    
    __weak typeof(self)weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [weakSelf.navigationController popViewControllerAnimated:YES];
    });
}

- (void)viewWillDisappear:(BOOL)animated {
    
    NSLog(@"%@ 即将消失",self);
}

- (void)dealloc {
    
    NSLog(@"%@ 已释放",self);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
