//
//  NextViewController.m
//  CBXChoseHudDemo
//
//  Created by 陆正现 on 2018/3/1.
//  Copyright © 2018年 陆正现. All rights reserved.
//

#import "NextViewController.h"

#import "CBXChoseHud.h"

@interface NextViewController ()

@end

@implementation NextViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor greenColor];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    [[CBXChoseHud shareHud] showHudWithContentTitle:@[@"标题1",@"标题2",    @"标题三很长很长标题三很长很长标题三很长很长标题三很长很长"] andFontArr:@[@(17),@(15),@(12)] andLeftChose:@"确定" andLeftColor:[UIColor greenColor] andRightChose:@"取消" andRightColor:[UIColor greenColor] inViewController:self];
    
    __weak typeof(self)weakSelf = self;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [weakSelf.navigationController popViewControllerAnimated:YES];
    });
}

- (void)viewWillDisappear:(BOOL)animated {
    
    NSLog(@"%@ 即将消失",self);
}

- (void)dealloc {
    
    NSLog(@"%@ 已释放",self);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
