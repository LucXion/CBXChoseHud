//
//  main.m
//  CBXHudViewToolDemo
//
//  Created by 陆正现 on 2018/3/26.
//  Copyright © 2018年 陆正现. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
