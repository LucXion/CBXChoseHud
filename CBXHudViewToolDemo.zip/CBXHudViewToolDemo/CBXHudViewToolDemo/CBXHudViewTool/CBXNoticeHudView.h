//
//  CBXNoticeHudView.h
//  精品课
//
//  Created by 陆正现 on 2018/3/1.
//  Copyright © 2018年 陆正现. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CBXNoticeHudView : UIView

@property(nonatomic,strong)UIImage *img;

@property(nonatomic,copy)NSString *content;

@end
